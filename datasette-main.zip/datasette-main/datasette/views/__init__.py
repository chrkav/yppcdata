class Context:
    "Base class for all documented contexts"
    pass
